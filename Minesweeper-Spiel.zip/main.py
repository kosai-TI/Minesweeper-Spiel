import sys
from game import Game

def main():
    size = int(10), int(10)# Hier werden die X-Achsen und Y-Achsen eingestellt
    prob = float(0.1)
    g = Game(size, prob)
    g.run()

if __name__ == '__main__':
    main()
